# BOQ Excel Store — ₹299

This starter package uses:
- GitHub Pages for the public storefront (`site/`)
- Render Web Service for order creation, signature verification and private file delivery (`backend/`)
- Razorpay Standard Checkout for payment

## Product file
`backend/private/BOQ_123_Items.xlsx` is the workbook selected from your latest 123-item final-rate-only BOQ file. It is stored in the backend, not the public website.

## 1) Create the private backend repository
Create a **private** GitHub repository, for example `BOQ-STORE-BACKEND`.
Upload the contents of the `backend/` folder, including `private/BOQ_123_Items.xlsx`.
Do not upload `.env` or real API secrets. `.gitignore` excludes `.env`.

## 2) Deploy backend on Render
Create a new **Web Service** from that private repository:
- Runtime: Node
- Build command: `npm install`
- Start command: `npm start`

In Render → Environment, add:
- `RAZORPAY_KEY_ID` = Razorpay Key ID
- `RAZORPAY_KEY_SECRET` = Razorpay Key Secret (backend only)
- `FRONTEND_ORIGIN` = exact GitHub Pages origin including trailing slash, e.g. `https://USERNAME.github.io/REPOSITORY/`
- `DOWNLOAD_SECRET` = a long random string (at least 32 characters)
- `NODE_ENV` = `production`

Deploy, then test `https://YOUR-RENDER-SERVICE.onrender.com/health` — it should return `{"ok":true}`.

## 3) Configure the public website
Create a **public** GitHub repository, e.g. `BOQ-STORE`.
Upload the contents of `site/` to the repository root.
Edit `site/index.html` before uploading:
- Replace `https://YOUR-RENDER-SERVICE.onrender.com` with your real Render service URL.
- Replace `YOUR_RAZORPAY_KEY_ID` with your Razorpay Key ID (this is the public Key ID, not the secret).

In GitHub → Settings → Pages:
- Source: Deploy from a branch
- Branch: `main`, folder `/ (root)`
Wait for GitHub Pages to publish the site. Use the exact published origin in Render's `FRONTEND_ORIGIN`.

## 4) Razorpay setup and testing
Use Razorpay Test Mode first. Put the Test Key ID and Test Key Secret in Render environment variables, and the Test Key ID in the website.
Complete a test payment and confirm:
- checkout opens,
- payment signature verification succeeds,
- the Excel file downloads only after successful verification.

After testing, replace both keys with Live Mode keys in Render and replace the public Key ID in `site/index.html`, then redeploy. Do not share the Key Secret or put it in HTML/GitHub Pages.

## Important security / operating notes
- The paid workbook must stay in the private backend repository; never put it in the public Pages repository or a public download URL.
- The backend fixes the amount at ₹299 (₹29,900 paise); the browser cannot change the price.
- The backend verifies Razorpay's checkout signature before issuing a short-lived download link.
- The short-lived download token is valid for 10 minutes. It is a temporary link, not a permanent customer account or device lock.
- For stronger production fulfilment, add persistent order/payment records and webhook reconciliation before scaling. This starter validates checkout signatures but does not maintain a customer database.
- Add your real support email and business/legal details to the storefront before launch.
- BOQ rates are indicative estimates; customers should validate them for their site, specifications and local market.

## Project layout
- `site/` — public static website for GitHub Pages
- `backend/` — Render server and private workbook
