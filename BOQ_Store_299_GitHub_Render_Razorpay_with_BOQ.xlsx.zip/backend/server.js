const express = require("express");
const cors = require("cors");
const Razorpay = require("razorpay");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const PRICE_PAISE = 29900;
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN;
const DOWNLOAD_SECRET = process.env.DOWNLOAD_SECRET;
const FILE_PATH = path.join(__dirname, "private", "BOQ_123_Items.xlsx");

if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET || !DOWNLOAD_SECRET || !FRONTEND_ORIGIN) {
  console.error("Missing required environment variables. See .env.example");
  process.exit(1);
}
if (!fs.existsSync(FILE_PATH)) {
  console.error("Paid workbook missing:", FILE_PATH);
  process.exit(1);
}

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET
});

app.use(cors({origin: FRONTEND_ORIGIN, methods:["GET","POST"], allowedHeaders:["Content-Type"]}));
app.use(express.json({limit:"20kb"}));

app.get("/health", (_req,res) => res.json({ok:true}));

app.post("/api/create-order", async (_req,res) => {
  try {
    const order = await razorpay.orders.create({
      amount: PRICE_PAISE, currency:"INR",
      receipt:"boq299_" + Date.now(),
      notes:{product:"Professional 123-Item BOQ Excel Workbook"}
    });
    res.json({id:order.id, amount:order.amount, currency:order.currency});
  } catch(err) {
    console.error("Order creation failed:", err.message);
    res.status(502).json({error:"Unable to start payment. Please try again."});
  }
});

app.post("/api/verify-payment", (req,res) => {
  const {razorpay_order_id, razorpay_payment_id, razorpay_signature} = req.body || {};
  if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
    return res.status(400).json({error:"Missing payment verification details."});
  }
  const expected = crypto.createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
    .update(`${razorpay_order_id}|${razorpay_payment_id}`).digest("hex");
  const a = Buffer.from(expected, "hex"), b = Buffer.from(razorpay_signature, "hex");
  if (a.length !== b.length || !crypto.timingSafeEqual(a,b)) {
    return res.status(400).json({error:"Payment signature is invalid. No download issued."});
  }
  // Short-lived signed download token; the file itself remains on the private backend.
  const expires = Date.now() + 10 * 60 * 1000;
  const payload = Buffer.from(JSON.stringify({payment:razorpay_payment_id, exp:expires})).toString("base64url");
  const sig = crypto.createHmac("sha256", DOWNLOAD_SECRET).update(payload).digest("hex");
  res.json({downloadUrl:`/download/${payload}.${sig}`});
});

app.get("/download/:token", (req,res) => {
  try {
    const [payload,sig] = req.params.token.split(".");
    if (!payload || !sig) return res.status(400).send("Invalid download link.");
    const expected = crypto.createHmac("sha256", DOWNLOAD_SECRET).update(payload).digest("hex");
    const a=Buffer.from(expected,"hex"), b=Buffer.from(sig,"hex");
    if(a.length!==b.length || !crypto.timingSafeEqual(a,b)) return res.status(403).send("Invalid download link.");
    const data=JSON.parse(Buffer.from(payload,"base64url").toString("utf8"));
    if(!data.payment || Date.now()>data.exp) return res.status(403).send("Download link expired. Contact support.");
    res.setHeader("Content-Type","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    res.download(FILE_PATH, "Professional_BOQ_123_Items.xlsx");
  } catch(err) { res.status(400).send("Invalid download link."); }
});

app.listen(PORT, () => console.log(`BOQ store backend listening on ${PORT}`));
